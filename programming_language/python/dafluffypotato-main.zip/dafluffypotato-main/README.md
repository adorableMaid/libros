# dafluffypotato

Analysis of the code of dafluffypotato to make a platform videogame with python

![](https://pythonprogramming.altervista.org/wp-content/uploads/2022/01/image-19.png)
